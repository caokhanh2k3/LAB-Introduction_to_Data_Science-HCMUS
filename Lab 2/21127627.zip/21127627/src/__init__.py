# Module information:
# - This folder contains the Python source codes used in this project.
# File: __init__.py
# Functionality: Making ```src``` become a Python module